document.addEventListener('DOMContentLoaded', () => {
  const sidebarLinks = document.querySelectorAll('[data-nav]');
  const currentPage = document.body.dataset.page;

  sidebarLinks.forEach(link => {
    if (link.dataset.nav === currentPage) {
      link.classList.add('active');
    }
  });

  const forgotForm = document.getElementById('forgot-form');
  const verifyForm = document.getElementById('verify-form');
  const resetForm = document.getElementById('reset-form');

  if (forgotForm) {
    forgotForm.addEventListener('submit', (e) => {
      e.preventDefault();
      document.getElementById('step-email').classList.add('hidden');
      document.getElementById('step-code').classList.remove('hidden');
    });
  }

  if (verifyForm) {
    verifyForm.addEventListener('submit', (e) => {
      e.preventDefault();
      document.getElementById('step-code').classList.add('hidden');
      document.getElementById('step-reset').classList.remove('hidden');
    });
  }

  if (resetForm) {
    resetForm.addEventListener('submit', (e) => {
      e.preventDefault();

      const newPass = document.getElementById('new-password').value.trim();
      const confirmPass = document.getElementById('confirm-password').value.trim();

      if (!newPass || !confirmPass) {
        alert('Vui lòng nhập đầy đủ mật khẩu mới.');
        return;
      }

      if (newPass !== confirmPass) {
        alert('Mật khẩu xác nhận chưa khớp.');
        return;
      }

      window.location.href = 'login.html';
    });
  }

  const loginForm = document.getElementById('login-form');
  if (loginForm) {
    loginForm.addEventListener('submit', (e) => {
      e.preventDefault();
      window.location.href = 'dashboard.html';
    });
  }

  const classSearch = document.getElementById('class-search');
  if (classSearch) {
    classSearch.addEventListener('input', () => {
      const keyword = classSearch.value.toLowerCase().trim();
      document.querySelectorAll('[data-class-row]').forEach(row => {
        const text = row.innerText.toLowerCase();
        row.style.display = text.includes(keyword) ? '' : 'none';
      });
    });
  }

  const studentSearch = document.getElementById('student-search');
  if (studentSearch) {
    studentSearch.addEventListener('input', () => {
      const keyword = studentSearch.value.toLowerCase().trim();
      document.querySelectorAll('[data-student-row]').forEach(row => {
        const text = row.innerText.toLowerCase();
        row.style.display = text.includes(keyword) ? '' : 'none';
      });
    });
  }

  const topicSearch = document.getElementById('topic-search');
  if (topicSearch) {
    topicSearch.addEventListener('input', () => {
      const keyword = topicSearch.value.toLowerCase().trim();
      document.querySelectorAll('[data-topic-row]').forEach(row => {
        const text = row.innerText.toLowerCase();
        row.style.display = text.includes(keyword) ? '' : 'none';
      });
    });
  }

  const testSearch = document.getElementById('test-search');
  if (testSearch) {
    testSearch.addEventListener('input', () => {
      const keyword = testSearch.value.toLowerCase().trim();
      document.querySelectorAll('[data-test-row]').forEach(row => {
        const text = row.innerText.toLowerCase();
        row.style.display = text.includes(keyword) ? '' : 'none';
      });
    });
  }

  const routeSearch = document.getElementById('route-search');
  if (routeSearch) {
    routeSearch.addEventListener('input', () => {
      const keyword = routeSearch.value.toLowerCase().trim();
      document.querySelectorAll('[data-route-row]').forEach(row => {
        const text = row.innerText.toLowerCase();
        row.style.display = text.includes(keyword) ? '' : 'none';
      });
    });
  }

  const accountForm = document.getElementById('account-form');
  if (accountForm) {
    accountForm.addEventListener('submit', (e) => {
      e.preventDefault();
      window.location.href = 'account.html';
    });
  }

  const toastClose = document.querySelectorAll('[data-close-toast]');
  toastClose.forEach(btn => {
    btn.addEventListener('click', () => {
      const toast = btn.closest('.toast');
      if (toast) {
        toast.classList.add('hidden');
      }
    });
  });
});