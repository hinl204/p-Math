document.addEventListener('DOMContentLoaded', () => {
  const sidebarLinks = document.querySelectorAll('[data-nav]');
  const currentPage = document.body.dataset.page;

  sidebarLinks.forEach(link => {
    if (link.dataset.nav === currentPage) link.classList.add('active');
  });

  const joinForm = document.getElementById('join-class-form');
  if (joinForm) {
    joinForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const code = document.getElementById('class-code').value.trim();
      if (!code) {
        alert('Vui lòng nhập mã lớp học.');
        return;
      }
      if (code !== 'PMATH7A1') {
        alert('Mã lớp học không tồn tại. Demo hợp lệ: PMATH7A1');
        return;
      }
      const toast = document.getElementById('join-success-toast');
      if (toast) toast.classList.remove('hidden');
      const joinedCard = document.getElementById('joined-class-card');
      if (joinedCard) joinedCard.classList.remove('hidden');
      joinForm.reset();
    });
  }

  document.querySelectorAll('[data-leave-class]').forEach(btn => {
    btn.addEventListener('click', () => {
      const ok = confirm('Bạn có chắc muốn rời lớp học này không?');
      if (!ok) return;
      const card = btn.closest('.class-card');
      if (card) card.classList.add('hidden');
    });
  });

  const forgotForm = document.getElementById('forgot-form');
  const verifyForm = document.getElementById('verify-form');
  const resetForm = document.getElementById('reset-form');

  if (forgotForm) {
    forgotForm.addEventListener('submit', (e) => {
      e.preventDefault();
      document.getElementById('step-email').classList.add('hidden');
      document.getElementById('step-code').classList.remove('hidden');
    });
  }

  if (verifyForm) {
    verifyForm.addEventListener('submit', (e) => {
      e.preventDefault();
      document.getElementById('step-code').classList.add('hidden');
      document.getElementById('step-reset').classList.remove('hidden');
    });
  }

  if (resetForm) {
    resetForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const newPass = document.getElementById('new-password').value.trim();
      const confirmPass = document.getElementById('confirm-password').value.trim();
      if (!newPass || !confirmPass) {
        alert('Vui lòng nhập đầy đủ mật khẩu mới.');
        return;
      }
      if (newPass.length < 8) {
        alert('Mật khẩu cần có ít nhất 8 ký tự.');
        return;
      }
      if (newPass !== confirmPass) {
        alert('Mật khẩu xác nhận chưa khớp.');
        return;
      }
      window.location.href = 'login.html';
    });
  }

  const loginForm = document.getElementById('login-form');
  if (loginForm) {
    loginForm.addEventListener('submit', (e) => {
      e.preventDefault();
      window.location.href = 'dashboard.html';
    });
  }

  const registerForm = document.getElementById('register-form');
  if (registerForm) {
    registerForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const password = document.getElementById('register-password').value.trim();
      const confirm = document.getElementById('register-confirm-password').value.trim();
      if (password.length < 8) {
        alert('Mật khẩu cần có ít nhất 8 ký tự.');
        return;
      }
      if (password !== confirm) {
        alert('Mật khẩu xác nhận chưa khớp.');
        return;
      }
      alert('Đăng ký tài khoản thành công.');
      window.location.href = 'login.html';
    });
  }

  const accountForm = document.getElementById('account-form');
  if (accountForm) {
    accountForm.addEventListener('submit', (e) => {
      e.preventDefault();
      alert('Lưu thay đổi thành công.');
      window.location.href = 'account.html';
    });
  }

  const testSubmitBtn = document.getElementById('submit-test-btn');
  const submitDialog = document.getElementById('submit-dialog');
  const confirmSubmitBtn = document.getElementById('confirm-submit-btn');
  const cancelSubmitBtn = document.getElementById('cancel-submit-btn');

  if (testSubmitBtn && submitDialog) {
    testSubmitBtn.addEventListener('click', () => submitDialog.classList.remove('hidden'));
  }
  if (cancelSubmitBtn && submitDialog) {
    cancelSubmitBtn.addEventListener('click', () => submitDialog.classList.add('hidden'));
  }
  if (confirmSubmitBtn) {
    confirmSubmitBtn.addEventListener('click', () => {
      window.location.href = 'test-history.html';
    });
  }

  document.querySelectorAll('[data-close-toast]').forEach(btn => {
    btn.addEventListener('click', () => {
      const toast = btn.closest('.toast');
      if (toast) toast.classList.add('hidden');
    });
  });

  const searchMap = [
    { inputId: 'class-search', rowSelector: '[data-class-card]' },
    { inputId: 'topic-search', rowSelector: '[data-topic-row]' },
    { inputId: 'history-search', rowSelector: '[data-history-row]' },
    { inputId: 'exercise-search', rowSelector: '[data-exercise-row]' }
  ];

  searchMap.forEach(({ inputId, rowSelector }) => {
    const input = document.getElementById(inputId);
    if (!input) return;
    input.addEventListener('input', () => {
      const keyword = input.value.toLowerCase().trim();
      document.querySelectorAll(rowSelector).forEach(row => {
        const text = row.innerText.toLowerCase();
        row.style.display = text.includes(keyword) ? '' : 'none';
      });
    });
  });
});
